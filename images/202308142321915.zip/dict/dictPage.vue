<!-- 字典管理-列表 -->
<template>
  <div>
    <!-- 高级搜索 -->
    <dict-query @onQuery="onQuery"></dict-query>

    <!-- 监听按钮数据 -->
    <dict-toolbar ref="editOrDelete" 
                  @onFlush="onFlush"
                  :single="this.single" 
                  :multiple="this.multiple" 
                  :ids="this.ids"
                  :queryParams="this.queryParams">
  </dict-toolbar>

    <!-- 列表信息-start --> 
    <el-table v-loading="loading" :data="typeList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="字典编号" align="center" prop="dictId" />
      <el-table-column label="字典名称" align="center" prop="dictName" :show-overflow-tooltip="true" />
      <el-table-column label="字典类型" align="center" :show-overflow-tooltip="true">
        <template slot-scope="scope">
          <router-link :to="'/system/dict-data/index/' + scope.row.dictId" class="link-type">
            <span>{{ scope.row.dictType }}</span>
          </router-link>
        </template>
      </el-table-column>
      <el-table-column label="状态" align="center" prop="status">
        <template slot-scope="scope">
          <dict-tag :options="dict.type.sys_normal_disable" :value="scope.row.status" />
        </template>
      </el-table-column>
      <el-table-column label="备注" align="center" prop="remark" :show-overflow-tooltip="true" />
      <el-table-column label="创建时间" align="center" prop="createTime" width="180">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.createTime) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['system:dict:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['system:dict:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页条 -->
    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"/>
    <!-- 列表信息-end   --> 

    <!--字段新增编辑-->
    <dict-add-edit ref="addEditCard" @onSuccess="onSuccess"></dict-add-edit>
  </div>
</template>

<script>
import dictQuery from "./dictQuery.vue";
import dictToolbar from "./dictToolbar.vue";
import { listType } from "@/api/system/dict/type";
import DictAddEdit from "./dictAddEdit.vue";

export default {
  name: "dictPage",
  components: { dictQuery, dictToolbar, DictAddEdit },
  dicts: ["sys_normal_disable"],
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 字典表格数据
      typeList: [],
      // 表单参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        dictName: undefined,
        dictType: undefined,
        status: undefined,
      },
      // 时间数据范围
      dateRange: [],
      //
      queryForm: {},
      // 总条数
      total: 0,
    };
  },
  /**
   * 当所有节点初始化之后调用接口
   */
  mounted() {
    this.getList();
  },
  methods: {
    /**
     * 修改按钮操作
     */
    handleUpdate(row) {
      this.$refs["editOrDelete"].handleUpdate(row);
    },
    /**
     * 删除按钮操作
     */
    handleDelete(row) {
      this.$refs["editOrDelete"].handleDelete(row);
    },
    /** 
     * 查询字典类型列表 
     */
    getList() {
      this.loading = true;
      listType(this.addDateRange(this.queryParams, this.dateRange)).then(
        (response) => {
          this.typeList = response.rows;
          this.total = response.total;
          this.loading = false;
        }
      );
    },
    /**
     * 搜索按钮
     */
    onQuery(queryForm = {}) {
      this.queryParams = queryForm.queryParams;
      this.dateRange = queryForm.dateRange;
      this.getList();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map((item) => item.dictId);
      this.single = selection.length != 1;
      this.multiple = !selection.length;
    },
    /**
     * 刷新页面
     */
    onFlush() {
      this.getList();
    },
    /**
     * 新增成功之后调用父组件
     */
    onSuccess() {
      this.getList();
    },
  },
};
</script>
