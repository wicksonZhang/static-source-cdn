<template>
    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button type="primary" plain icon="el-icon-plus" size="mini" @click="handleAdd" v-hasPermi="['system:dict:add']">新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button type="success" plain icon="el-icon-edit" size="mini" :disabled="single" @click="handleUpdate" v-hasPermi="['system:dict:edit']">修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button type="danger" plain icon="el-icon-delete" size="mini" :disabled="multiple" @click="handleDelete" v-hasPermi="['system:dict:remove']">删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button type="warning" plain icon="el-icon-download" size="mini" @click="handleExport" v-hasPermi="['system:dict:export']">导出</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button type="danger" plain icon="el-icon-refresh" size="mini" @click="handleRefreshCache" v-hasPermi="['system:dict:remove']">刷新缓存</el-button>
      </el-col>
    </el-row>
</template>
<script>
import { EventBus } from '@/utils/eventBus';
import { getType, delType, refreshCache } from "@/api/system/dict/type";

export default {
  name: 'dictToolbar',
  props: {
    // 选中数组
    ids: {
      type: Array,
      require: true
    },
    // 非单个禁用
    single: {
      type: Boolean,
      require: true
    },
    // 非多个禁用
    multiple: {
      type: Boolean,
      require: true
    },
    // 表单参数
    queryParams: {
      type: Object
    }
  },
  data() {
    return {
      // 显示搜索条件
      showSearch: true
    }
  },
  methods : {
    /** 
     * 新增按钮操作 
     */
    handleAdd() {
      console.log("handleAdd()")
      EventBus.$emit('dictToolbarObj', {open: true, form: {}, title: "新增字典类型"});
    },
    /** 
     * 修改按钮操作 
     */
    handleUpdate(row) {
      const dictId = row.dictId || this.ids
      getType(dictId).then(response => {
        if(response.data){
          EventBus.$emit('dictToolbarObj', {open: true, form : response.data, title : "修改字典类型"});
        }
      });
    },
    /** 
     * 删除按钮操作 
     */
    handleDelete(row) {
      const dictIds = row.dictId || this.ids;
      this.$modal.confirm('是否确认删除字典编号为"' + dictIds + '"的数据项？')
        .then(function () { return delType(dictIds); })
        .then(() => {
          this.$emit("onFlush");
          this.$modal.msgSuccess("删除成功");
        })
        .catch(() => {});
    },
    /** 
     * 导出按钮操作 
     */
    handleExport() {
      this.download('system/dict/type/export', {
        ...this.queryParams
      }, `type_${new Date().getTime()}.xlsx`)
    },
    /** 
     * 刷新缓存按钮操作 
     */
    handleRefreshCache() {
      refreshCache().then(() => {
        this.$modal.msgSuccess("刷新成功");
        this.$store.dispatch('dict/cleanDict');
      });
    }
  }
}
</script>

