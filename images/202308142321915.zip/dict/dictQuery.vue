<template>
  <el-form :model="queryParams" ref="queryForm" size="small" v-show="showSearch" label-width="68px" :inline="true" >
      <el-form-item label="字典名称" prop="dictName">
        <el-input
          v-model="queryParams.dictName"
          placeholder="请输入字典名称"
          clearable
          style="width: 240px"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="字典类型" prop="dictType">
        <el-input
          v-model="queryParams.dictType"
          placeholder="请输入字典类型"
          clearable
          style="width: 240px"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="状态" prop="status">
        <el-select v-model="queryParams.status" placeholder="字典状态" clearable style="width: 240px">
          <el-option v-for="dict in dict.type.sys_normal_disable"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="创建时间">
        <el-date-picker
          v-model="dateRange"
          style="width: 240px"
          value-format="yyyy-MM-dd"
          type="daterange"
          range-separator="-"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
        ></el-date-picker>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>
</template>

<script>
import { EventBus } from '@/utils/eventBus';

export default {
  name: 'dictQuery',
  dicts: ['sys_normal_disable'],
  data() {
    return {
      queryParams: {},
      // 日期范围
      dateRange: [],
      showSearch: true
    }
  },
  created() {
    EventBus.$on('dictToolbarSearch', obj => {
      this.showSearch = obj.showSearch
    });
  },
  methods : {
    /**
     * 搜索按钮
     */
    handleQuery() {
      let queryForm = {
        queryParams: this.queryParams,
        dateRange: this.dateRange
      }
      this.$emit('onQuery', queryForm)
    },
    /**
     * 重置按钮
     */
    resetQuery() {
      this.queryParams = {},
      this.dateRange = []
    }
  }
}

</script>
